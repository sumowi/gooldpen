---
title: {{ title }}
date: {{ date }}
client:
cate:
task:
author:
featured: /img/default-new-blog.jpg
background: /img/default-background.jpg
section: project
---
