---
title: {{ title }}
date: {{ date }}
tags:
author:
featured: /img/default-new-blog.jpg
background: /img/default-background.jpg
section: blog
---
